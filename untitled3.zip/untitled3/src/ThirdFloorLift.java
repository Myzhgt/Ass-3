// Лифт для третьего этажа
class ThirdFloorLift {
    private int selectedApartment;

    public ThirdFloorLift() {
        this.selectedApartment = selectedApartment;
    }

    void moveToThirdFloor(int selectedApartment) {
        System.out.println("Лифт перемещается на 3 этаж.");  // Вывод сообщения о перемещении
    }

    void exitFromThirdFloor() {
        System.out.println("Вы вышли из лифта на 3 этаже");  // Вывод сообщения о выходе с третьего этажа
    }
}