// Лифт для второго этажа
class SecondFloorLift {
    private int selectedApartment;

    public SecondFloorLift() {
        this.selectedApartment = selectedApartment;
    }

    void moveToSecondFloor(int selectedApartment) {
        System.out.println("Лифт перемещается на 2 этаж.");  // Вывод сообщения о перемещении
    }

    void exitFromSecondFloor() {
        System.out.println("Вы вышли из лифта на 2 этаже");  // Вывод сообщения о выходе с второго этажа
    }
}