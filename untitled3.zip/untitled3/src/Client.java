interface Client {
    String getName();
}