// Интерфейс для лифта
interface Lift {
    void connect();    // Зайти в лифт
    void disconnect(); // Выйти из лифта
}