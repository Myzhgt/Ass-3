// Лифт для первого этажа
class FirstFloorLift {
    private int selectedApartment;

    public FirstFloorLift() {
        this.selectedApartment = selectedApartment;
    }

    void moveToFirstFloor(int selectedApartment) {
        System.out.println("Лифт перемещается на 1 этаж.");  // Вывод сообщения о перемещении
    }

    void exitFromFirstFloor() {
        System.out.println("Вы вышли из лифта на 1 этаже");  // Вывод сообщения о выходе с первого этажа
    }
}